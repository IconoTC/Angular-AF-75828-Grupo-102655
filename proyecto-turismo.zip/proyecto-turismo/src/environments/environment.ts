// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyDCq8zY5RBrcawCgBvu4cNWQktcMlgJ4Ik",
    authDomain: "angular-indra-27-noviembre.firebaseapp.com",
    projectId: "angular-indra-27-noviembre",
    storageBucket: "angular-indra-27-noviembre.firebasestorage.app",
    messagingSenderId: "178830723769",
    appId: "1:178830723769:web:da41f6692336c9abb1e968"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
