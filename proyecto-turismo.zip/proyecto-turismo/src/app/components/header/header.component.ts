import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  idioma: string = 'es';

  constructor(private translateService: TranslateService) {
    translateService.setDefaultLang(this.idioma);
  }

  cambiarIdioma(nuevoIdioma: string){
    this.idioma = nuevoIdioma;
    this.translateService.use(nuevoIdioma);
  }

  ngOnInit(): void {
  }

}
