import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  email: string | null = '';
  mostrar: boolean = false;

  constructor(private loginService: LoginService) {
    loginService.comprobarLogado().subscribe(user => {
      if (user){
        this.email = user.email;
        this.mostrar = true;
      } else {
        this.email = null;
      }
    })
  }

  salir(){
    this.loginService.logout()
      .then(() => {
        alert("Sesion cerrada")
        this.mostrar = false;
      })
      .catch(error => {
        console.log(error)
      })
  }

  ngOnInit(): void {
  }

}
