import { Component } from '@angular/core';
import { PokemonService } from './services/pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  pokemons: any[] = [];
  url_siguientes: string = '';
  url_anteriores: string = '';

  constructor(private pokemonService: PokemonService){

    // Esto no se puede hacer
    // this.pokemons = pokemonService.getAll();

    pokemonService.getAll().subscribe(datos => {
      console.log(datos);
      this.pokemons = datos.results;
      this.url_anteriores = datos.previous;
      this.url_siguientes = datos.next;
    }, error => {
      console.log(error);
    });
  }

  atras(){
    this.pokemonService.emitirPeticion(this.url_anteriores).subscribe(datos => {
      this.pokemons = datos.results;
      this.url_anteriores = datos.previous;
      this.url_siguientes = datos.next;
    }, error => {
      console.log(error);
    });
  }

  adelante(){
    this.pokemonService.emitirPeticion(this.url_siguientes).subscribe(datos => {
      this.pokemons = datos.results;
      this.url_anteriores = datos.previous;
      this.url_siguientes = datos.next;
    }, error => {
      console.log(error);
    });
  }
}
