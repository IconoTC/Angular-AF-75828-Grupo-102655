export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDCq8zY5RBrcawCgBvu4cNWQktcMlgJ4Ik",
    authDomain: "angular-indra-27-noviembre.firebaseapp.com",
    projectId: "angular-indra-27-noviembre",
    storageBucket: "angular-indra-27-noviembre.firebasestorage.app",
    messagingSenderId: "178830723769",
    appId: "1:178830723769:web:da41f6692336c9abb1e968"
  }
};
